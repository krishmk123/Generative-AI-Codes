Contains the presentation decks covered in the workshop with useful coverage on concepts around Generative AI and Agentic AI
